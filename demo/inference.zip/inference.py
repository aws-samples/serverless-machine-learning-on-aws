from mxnet.image import imdecode
from gluoncv import model_zoo, data, utils
from gluoncv.data.transforms.pose import detector_to_alpha_pose, heatmap_to_coord_alpha_pose

import requests
from io import BytesIO
import json
import base64

detector = model_zoo.get_model('yolo3_mobilenet1.0_coco', pretrained=True, root='/tmp/')
pose_estimator = model_zoo.get_model('mobile_pose_resnet50_v1b', pretrained=True, root='/tmp/')
detector.reset_class(["person"], reuse_weights=['person'])

def lambda_handler(event, context):
    try:
        url = event['img_url']
        response = requests.get(url)
        img = imdecode(response.content)
        x, img = data.transforms.presets.yolo.transform_test([img], short=320)

        class_IDs, scores, bounding_boxs = detector(x)
        pose_input, upscale_bbox = detector_to_alpha_pose(img, class_IDs, 
                                                          scores, bounding_boxs)
        predicted_heatmap = pose_estimator(pose_input)
        pred_coords, confidence = heatmap_to_coord_alpha_pose(predicted_heatmap, 
                                                              upscale_bbox)

        output = utils.viz.plot_keypoints(img, pred_coords, confidence,
                                          class_IDs, bounding_boxs, scores,
                                          box_thresh=0.5, keypoint_thresh=0.2)
        output.axis('off')

        f = BytesIO()
        output.figure.savefig(f, format='jpeg', bbox_inches='tight')
        return base64.b64encode(f.getvalue())
    except Exception as e:
        raise Exception('ProcessingError')
